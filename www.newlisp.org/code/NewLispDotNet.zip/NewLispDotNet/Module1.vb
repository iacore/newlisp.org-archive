
Module Module1
    Private Declare Function LoadLibraryA Lib "kernel32" (ByVal s As String) As Integer
    Private Declare Sub FreeLibrary Lib "kernel32" (ByVal h As Integer)
    Private Declare Function dllNewlispeval Lib "newlisp" Alias "dllEvalStr" (ByVal txt As String) As System.Text.StringBuilder
    Dim NewLispHandle As Integer = 0

    Sub LoadNewLISP()
        Dim AppPath, mylib, mypath As String
        Dim SlashPos As Integer
        Dim hinst As Integer
        If NewLispHandle <> 0 Then Exit Sub
        AppPath = System.Reflection.Assembly.GetExecutingAssembly.Location()
        SlashPos = InStrRev(AppPath, "\")
        AppPath = Left(AppPath, SlashPos - 1)
        mylib = AppPath & "\newlisp.dll"
        NewLispHandle = LoadLibraryA(mylib)
        If NewLispHandle = 0 Then
            mypath = InputBox("Directory where NewLISP.dll lives", "NewLISP Path")
            If Right(mypath, 1) = "\" Then mypath = Left(mypath, Len(mypath) - 1)
            mylib = mypath & "\newlisp.dll"
            NewLispHandle = LoadLibraryA(mylib)
        End If
        If NewLispHandle = 0 Then
            MsgBox("NewLISP cannot be found")
            End
        End If
    End Sub


    Public Function NewLisp(ByVal LispExpression As String) As String
        Dim ResultObject As System.Text.StringBuilder
        ResultObject = dllNewlispeval(LispExpression)
        Return ResultObject.ToString
    End Function


End Module
